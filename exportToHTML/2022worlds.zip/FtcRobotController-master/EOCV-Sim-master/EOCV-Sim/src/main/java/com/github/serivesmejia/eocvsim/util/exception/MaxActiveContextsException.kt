package com.github.serivesmejia.eocvsim.util.exception

class MaxActiveContextsException(message: String = "") : Exception(message)