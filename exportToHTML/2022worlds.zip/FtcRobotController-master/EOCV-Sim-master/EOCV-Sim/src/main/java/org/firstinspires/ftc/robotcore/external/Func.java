package org.firstinspires.ftc.robotcore.external;

public interface Func<T> {

    T value();

}
