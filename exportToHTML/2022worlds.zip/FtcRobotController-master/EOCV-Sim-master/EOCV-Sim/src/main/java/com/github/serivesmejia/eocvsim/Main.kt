@file:JvmName("Main")

package com.github.serivesmejia.eocvsim

fun main() = EOCVSim().init()